local Criterion = nn.Criterion

Criterion.toBatch = nn.Module.toBatch
Criterion.fromBatch = nn.Module.fromBatch
