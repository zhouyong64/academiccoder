seq = nn.Sequencer(rnn)
seq:forward(input)